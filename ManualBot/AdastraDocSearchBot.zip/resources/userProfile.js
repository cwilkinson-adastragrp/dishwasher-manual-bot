// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

class UserProfile {
    constructor(chat_hist) {
        this.chat_hist = chat_hist
    }
}

module.exports.UserProfile = UserProfile;

